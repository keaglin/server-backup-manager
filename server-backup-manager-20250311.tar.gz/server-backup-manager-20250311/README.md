# Server Backup Manager Deployment Guide

This guide explains how to deploy the Server Backup Manager as a systemd service on an Ubuntu server.

## Prerequisites

- Ubuntu Server (18.04 or newer)
- Root or sudo access

## Deployment Steps

1. **Transfer files to the server**

   Transfer the following files to your Ubuntu server:
   - `server-backup-manager` (the compiled executable)
   - `server-backup-manager.service` (the systemd service file)
   - `deploy.sh` (the deployment script)
   - `setup-r2.sh` (the R2 setup script)
   - `config/` directory with your configuration files

   You can use `scp` or any other file transfer method:

   ```bash
   scp server-backup-manager server-backup-manager.service deploy.sh setup-r2.sh user@your-server:~/
   scp -r config user@your-server:~/
   ```

2. **(Optional) Configure Cloudflare R2 for backup storage**

   If you want to use Cloudflare R2 for backup storage, run the setup script:

   ```bash
   sudo ./setup-r2.sh
   ```

   You'll need:
   - The R2 endpoint URL (provided by Cloudflare when you create an API token)
   - R2 Access Key and Secret Key (create these in the R2 dashboard)
   - Bucket name (create this in the R2 dashboard)

   The script will create a properly formatted configuration file for the server-backup-manager.

3. **Run the deployment script**

   SSH into your server and run the deployment script:

   ```bash
   ssh user@your-server
   cd ~/
   sudo ./deploy.sh
   ```

   The script will:
   - Create the installation directory at `/opt/server-backup-manager`
   - Copy the executable and configuration files
   - Install and start the systemd service

4. **Verify the service is running**

   ```bash
   sudo systemctl status server-backup-manager
   ```

   You should see that the service is active (running).

## Managing the Service

- **Start the service**:
  ```bash
  sudo systemctl start server-backup-manager
  ```

- **Stop the service**:
  ```bash
  sudo systemctl stop server-backup-manager
  ```

- **Restart the service**:
  ```bash
  sudo systemctl restart server-backup-manager
  ```

- **View logs**:
  ```bash
  sudo journalctl -u server-backup-manager -f
  ```

## Configuration

The configuration file is located at `/opt/server-backup-manager/config/config.json`. After modifying the configuration, restart the service for changes to take effect:

```bash
sudo systemctl restart server-backup-manager
```

### Configuration Structure

The server-backup-manager expects a specific configuration structure. Here's an example:

```json
{
  "BackupDir": "/home/ghost/backups",
  "BucketName": "your-bucket-name",
  "BucketEndpoint": "your-endpoint.r2.cloudflarestorage.com",
  "AccessKeyID": "your-access-key",
  "SecretAccessKey": "your-secret-key",
  "UseSSL": true,
  "RetentionDays": 14,
  "UploadSchedule": "0 2 * * *",
  "RunOnce": false,
  "InitializeMode": false,
  "EnableMonitoring": false,
  "MonitorPaths": [
    "/home/ghost/backups",
    "/var/lib/docker/volumes"
  ],
  "DiskThresholdPercent": 85.0,
  "MonitorInterval": "1h",
  "WebhookURLs": [],
  "WebhookTimeout": "30s"
}
```

### Backup Retention and Scheduling

The server-backup-manager can be configured to:

1. **Keep backups for a specified number of days** (controlled by `RetentionDays`)
2. **Upload backups to Cloudflare R2** (using the S3-compatible API)
3. **Run backups on a schedule** (controlled by `UploadSchedule` using cron syntax)

### Disk Space Monitoring

The server-backup-manager can monitor disk space usage and send alerts when it exceeds a threshold:

1. Set `EnableMonitoring` to `true` to enable this feature
2. Configure `MonitorPaths` to specify which directories to monitor
3. Set `DiskThresholdPercent` to the threshold percentage (e.g., 85.0 for 85%)
4. **Important**: When monitoring is enabled, at least one webhook URL must be provided in the `WebhookURLs` array for notifications

Example webhook configuration:
```json
"EnableMonitoring": true,
"WebhookURLs": ["https://discord.com/api/webhooks/your-webhook-url"]
```

You can use webhooks from services like Discord, Slack, or any custom HTTP endpoint that can receive POST requests.

## Updating the Service

To update the service with a new version:

1. Transfer the new executable to your server
2. Stop the service: `sudo systemctl stop server-backup-manager`
3. Replace the executable: `sudo cp server-backup-manager /opt/server-backup-manager/`
4. Make it executable: `sudo chmod +x /opt/server-backup-manager/server-backup-manager`
5. Start the service: `sudo systemctl start server-backup-manager`

## Troubleshooting

If the service fails to start:

1. Check the logs: `sudo journalctl -u server-backup-manager -e`
2. Verify the configuration file is valid
3. Ensure the executable has proper permissions
4. Check that all required directories exist and are accessible 