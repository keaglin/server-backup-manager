#!/bin/bash

# Setup script for Cloudflare R2 credentials
# This script helps configure the server-backup-manager to use Cloudflare R2

set -e

CONFIG_FILE="/opt/server-backup-manager/config/config.json"
TEMP_CONFIG_FILE="/tmp/server-backup-config.json"

echo "Cloudflare R2 Setup for Server Backup Manager"
echo "============================================="
echo
echo "This script will help you configure your server-backup-manager to use Cloudflare R2 for backup storage."
echo "You'll need your R2 Access Key, Secret Key, and the endpoint URL provided by Cloudflare."
echo

# Check if config file exists
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Warning: Config file not found at $CONFIG_FILE"
    echo "A new configuration file will be created."
    # Create directory if it doesn't exist
    sudo mkdir -p "$(dirname "$CONFIG_FILE")"
else
    # Backup existing config
    sudo cp "$CONFIG_FILE" "${CONFIG_FILE}.bak"
    echo "Backed up existing configuration to ${CONFIG_FILE}.bak"
fi

# Get R2 endpoint URL
echo "When you create an API token in Cloudflare R2, they provide you with an endpoint URL."
echo "It should look like: https://<identifier>.r2.cloudflarestorage.com"
read -p "Enter your R2 endpoint URL: " ENDPOINT_URL
if [ -z "$ENDPOINT_URL" ]; then
    echo "Endpoint URL cannot be empty"
    exit 1
fi

# Remove https:// if present
ENDPOINT=${ENDPOINT_URL#https://}

# Get R2 bucket name
read -p "Enter your R2 bucket name [server-backups]: " BUCKET_NAME
BUCKET_NAME=${BUCKET_NAME:-server-backups}

# Get R2 Access Key
read -p "Enter your R2 Access Key ID: " ACCESS_KEY
if [ -z "$ACCESS_KEY" ]; then
    echo "Access Key cannot be empty"
    exit 1
fi

# Get R2 Secret Key
read -s -p "Enter your R2 Secret Access Key: " SECRET_KEY
echo
if [ -z "$SECRET_KEY" ]; then
    echo "Secret Key cannot be empty"
    exit 1
fi

# Get backup directory
read -p "Enter backup directory [/home/ghost/backups]: " BACKUP_DIR
BACKUP_DIR=${BACKUP_DIR:-/home/ghost/backups}

# Get retention days
read -p "Enter backup retention days [14]: " RETENTION_DAYS
RETENTION_DAYS=${RETENTION_DAYS:-14}

# Get upload schedule
read -p "Enter upload schedule (cron expression) [0 2 * * *]: " UPLOAD_SCHEDULE
UPLOAD_SCHEDULE=${UPLOAD_SCHEDULE:-"0 2 * * *"}

# Ask about monitoring
read -p "Enable disk space monitoring? [y/N]: " ENABLE_MONITORING
ENABLE_MONITORING=${ENABLE_MONITORING:-n}

# Convert to lowercase
ENABLE_MONITORING=$(echo "$ENABLE_MONITORING" | tr '[:upper:]' '[:lower:]')

# Default webhook URLs
WEBHOOK_URLS="[]"

# If monitoring is enabled, ask for webhook URL
if [[ "$ENABLE_MONITORING" == "y" || "$ENABLE_MONITORING" == "yes" ]]; then
    ENABLE_MONITORING="true"
    
    echo
    echo "Monitoring requires at least one webhook URL for notifications."
    echo "Examples: Discord webhook, Slack webhook, or a custom HTTP endpoint."
    read -p "Enter webhook URL: " WEBHOOK_URL
    
    if [ -z "$WEBHOOK_URL" ]; then
        echo "Warning: Webhook URL is required for monitoring. Using a placeholder URL."
        WEBHOOK_URL="https://example.com/webhook"
    fi
    
    # Format as JSON array
    WEBHOOK_URLS="[\"$WEBHOOK_URL\"]"
    
    # Ask for additional webhooks
    read -p "Add another webhook URL? [y/N]: " ADD_ANOTHER
    while [[ "${ADD_ANOTHER,,}" == "y" || "${ADD_ANOTHER,,}" == "yes" ]]; do
        read -p "Enter additional webhook URL: " ADDITIONAL_URL
        if [ ! -z "$ADDITIONAL_URL" ]; then
            # Remove the closing bracket and add the new URL
            WEBHOOK_URLS="${WEBHOOK_URLS%]}, \"$ADDITIONAL_URL\"]"
        fi
        read -p "Add another webhook URL? [y/N]: " ADD_ANOTHER
    done
else
    ENABLE_MONITORING="false"
fi

# Get disk threshold
DISK_THRESHOLD="85.0"
if [[ "$ENABLE_MONITORING" == "true" ]]; then
    read -p "Enter disk usage threshold percentage [85.0]: " DISK_THRESHOLD_INPUT
    DISK_THRESHOLD=${DISK_THRESHOLD_INPUT:-85.0}
fi

# Create configuration file
cat > "$TEMP_CONFIG_FILE" << EOF
{
  "BackupDir": "$BACKUP_DIR",
  "BucketName": "$BUCKET_NAME",
  "BucketEndpoint": "$ENDPOINT",
  "AccessKeyID": "$ACCESS_KEY",
  "SecretAccessKey": "$SECRET_KEY",
  "UseSSL": true,
  "RetentionDays": $RETENTION_DAYS,
  "UploadSchedule": "$UPLOAD_SCHEDULE",
  "RunOnce": false,
  "InitializeMode": false,
  "EnableMonitoring": $ENABLE_MONITORING,
  "MonitorPaths": [
    "$BACKUP_DIR",
    "/var/lib/docker/volumes"
  ],
  "DiskThresholdPercent": $DISK_THRESHOLD,
  "MonitorInterval": "1h",
  "WebhookURLs": $WEBHOOK_URLS,
  "WebhookTimeout": "30s"
}
EOF

# Copy the configuration file to the destination
sudo cp "$TEMP_CONFIG_FILE" "$CONFIG_FILE"
sudo chmod 644 "$CONFIG_FILE"
rm "$TEMP_CONFIG_FILE"

echo
echo "Configuration updated successfully!"
echo
echo "Your server-backup-manager is now configured to:"
echo "1. Keep backups for $RETENTION_DAYS days"
echo "2. Upload backups to Cloudflare R2 bucket '$BUCKET_NAME'"
echo "3. Connect to R2 using endpoint: $ENDPOINT"
echo "4. Run backups according to schedule: $UPLOAD_SCHEDULE"
if [[ "$ENABLE_MONITORING" == "true" ]]; then
    echo "5. Monitor disk space and send alerts when usage exceeds $DISK_THRESHOLD%"
else
    echo "5. Disk space monitoring is disabled"
fi
echo
echo "To apply these changes, restart the service:"
echo "  sudo systemctl restart server-backup-manager"
echo
echo "To check the service status:"
echo "  sudo systemctl status server-backup-manager" 